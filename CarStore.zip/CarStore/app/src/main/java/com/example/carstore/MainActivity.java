package com.example.carstore;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.os.Bundle;
import android.view.DragEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements FirstDialog.Dialog1Listener ,
        SecondDialog.Dialog2Listener, ThirdDialog.Dialog3Listener, AddMoneyDialog.AddMoneyListener {
    public ImageButton IB1, IB2, IB3;
    public Button AM;
    public TextView textViewMoney, title;
    public float money = 0;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        IB1 = (ImageButton) findViewById(R.id.item1);
        IB2 = (ImageButton) findViewById(R.id.item2);
        IB3 = (ImageButton) findViewById(R.id.item3);
        AM = (Button) findViewById(R.id.add_money) ;
        textViewMoney = (TextView) findViewById(R.id.Money) ;
        title = (TextView) findViewById(R.id.textView) ;


        IB1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialog(1);
            }
        });
        IB2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialog(2);
            }
        });
        IB3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialog(3);
            }
        });

        AM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialog(4);
            }
        });
    }

    public void openDialog(int id){

        FirstDialog item1 = new FirstDialog();
        SecondDialog item2 = new SecondDialog();
        ThirdDialog item3 = new ThirdDialog();
        AddMoneyDialog amdialog = new AddMoneyDialog();
        if (id==1){
            item1.show(getSupportFragmentManager(),"Item1");
        }
        if (id==2){
            item2.show(getSupportFragmentManager(),"Item2");
        }
        if (id==3){
            item3.show(getSupportFragmentManager(),"Item3");
        }
        if (id==4){
            amdialog.show(getSupportFragmentManager(),"Addmoney");
        }

    }

    @Override
    public void applyPurchase1() {
        if (money > 10000){
            money = money -10000;
            String moneystr = Float.toString(money);

            textViewMoney.setText('S'+moneystr);
            IB1.setVisibility(View.GONE);
            title.setText("Purchase Successed!");
        } else{
            title.setText("Not enough money. Please add money with the botton below.");
        }
    }

    @Override
    public void applyPurchase2() {
        if (money > 20000){
            money = money -20000;
            String moneystr = Float.toString(money);

            textViewMoney.setText('S'+moneystr);
            IB2.setVisibility(View.GONE);
            title.setText("Purchase Successed!");
        } else{
            title.setText("Not enough money. Please add money with the botton below.");
        }
    }


    @Override
    public void applyPurchase3() {
        if (money > 18000){
            money = money -18000;
            String moneystr = Float.toString(money);

            textViewMoney.setText('S'+moneystr);
            IB3.setVisibility(View.GONE);
            title.setText("Purchase Successed!");
        } else{
            title.setText("Not enough money. Please add money with the botton below.");
        }


    }
    @Override
    public void applyAddMoney(String input) {
        try{
            money = money + Float.parseFloat(input);
        } catch (Exception e) {
            e.printStackTrace();
        }

        String moneystr = Float.toString(money);

        textViewMoney.setText('S'+moneystr);
        title.setText("Add money successed!");
    }
}
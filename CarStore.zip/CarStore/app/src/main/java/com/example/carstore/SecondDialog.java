package com.example.carstore;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

public class SecondDialog extends AppCompatDialogFragment {
    private SecondDialog.Dialog2Listener listener;
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder1 = new AlertDialog.Builder(getActivity());
        builder1.setTitle("Tesla Model Y")
                .setView(R.layout.item2)
                .setPositiveButton("Purchase", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        listener.applyPurchase2();
                    }
                })
                .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
        return builder1.create();
    }
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            listener = (SecondDialog.Dialog2Listener) context;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public interface Dialog2Listener{
        void applyPurchase2();
    }


}

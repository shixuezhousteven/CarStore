package com.example.carstore;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

public class ThirdDialog extends AppCompatDialogFragment {
    private ThirdDialog.Dialog3Listener listener;
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder1 = new AlertDialog.Builder(getActivity());
        builder1.setTitle("Audi A4")
                .setView(R.layout.item3)
                .setPositiveButton("Purchase", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        listener.applyPurchase3();
                    }
                })
                .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
        return builder1.create();
    }
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            listener = (ThirdDialog.Dialog3Listener) context;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public interface Dialog3Listener{
        void applyPurchase3();
    }

}
